from typing import List
from langchain_ollama import OllamaLLM
from langchain.prompts import PromptTemplate
from langchain.chains import LLMChain

class QuestionDecomposer:
    def __init__(self, model_name: str = "llama3.1"):
        """Initialize question decomposer with LLM.
        
        Args:
            model_name: Name of the Ollama model to use
        """
        self.llm = OllamaLLM(model=model_name)
        
    def decompose_question(self, question: str, user_answer: str) -> List[str]:
        """Decompose a complex question into sub-questions.
        
        Args:
            question: The original complex question
            user_answer: The user's answer to the question
            
        Returns:
            A list of sub-questions
        """
        template = """
        You are an expert at breaking down complex questions into simpler sub-questions.
        
        Original Question: {question}
        User's Answer: {user_answer}
        
        Your task is to break down the original question into 2-5 sub-questions that would help evaluate whether the evidence supports the user's answer.
        
        These sub-questions should:
        1. Be simpler than the original question
        2. Cover different aspects of the original question
        3. When answered together, help determine if the user's answer is supported by evidence
        4. Be specific and focused
        
        Format your response as a numbered list of sub-questions only, with no introduction or explanation.
        
        If the question is already simple and doesn't require decomposition, return the original question with the prefix "ORIGINAL:".
        """
        
        prompt = PromptTemplate(
            template=template,
            input_variables=["question", "user_answer"]
        )
        
        chain = LLMChain(llm=self.llm, prompt=prompt)
        result = chain.invoke({"question": question, "user_answer": user_answer})
        response_text = result["text"].strip() if "text" in result else str(result)
        
        # Check if the response indicates the question is simple
        if response_text.startswith("ORIGINAL:"):
            return [question]
        
        # Parse the numbered list of sub-questions
        sub_questions = []
        for line in response_text.split('\n'):
            line = line.strip()
            if line and (line[0].isdigit() or line.startswith("- ")):
                # Remove the numbering or bullet point and any leading/trailing whitespace
                sub_question = line[line.find(' ')+1:].strip()
                if sub_question:
                    sub_questions.append(sub_question)
        
        # If parsing failed, return the original question
        if not sub_questions:
            return [question]
            
        return sub_questions 