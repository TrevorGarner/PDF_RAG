import os
import argparse
from typing import List, Optional, Dict, Any

from pdf_loader import PDFDocumentLoader
from vector_store import VectorStore
from evidence_evaluator import EvidenceEvaluator
from evidence_agent import EvidenceAgent
from response_recorder import ResponseRecorder

class PDFEvidenceVerifier:
    def __init__(
        self,
        pdf_dir: str = "PDF files",
        model_name: str = "llama3.1",
        vector_store_dir: str = "chroma_db",
        output_dir: str = "evaluation_results",
        use_agent: bool = True
    ):
        """Initialize the PDF evidence verification system.
        
        Args:
            pdf_dir: Directory containing PDF files
            model_name: Name of Ollama model to use
            vector_store_dir: Directory to store vector database
            output_dir: Directory to store evaluation results
            use_agent: Whether to use the agent-based approach
        """
        self.pdf_dir = pdf_dir
        self.model_name = model_name
        self.use_agent = use_agent
        
        # Initialize components
        self.pdf_loader = PDFDocumentLoader(pdf_dir)
        self.vector_store = VectorStore(persist_directory=vector_store_dir, model_name="mxbai-embed-large")
        self.evaluator = EvidenceEvaluator(model_name=model_name)
        self.agent = EvidenceAgent(vector_store=self.vector_store, model_name=model_name)
        self.recorder = ResponseRecorder(output_dir=output_dir)
        
    def setup(self, force_rebuild: bool = False) -> None:
        """Set up the system by loading documents and creating vector store.
        
        Args:
            force_rebuild: Whether to force rebuilding the vector store
        """
        # Try to load existing vector store
        if not force_rebuild and self.vector_store.load_vector_store():
            print(f"Loaded existing vector store.")
            return
            
        print(f"Loading PDF documents from {self.pdf_dir}...")
        documents = self.pdf_loader.load_documents()
        
        if not documents:
            print(f"No PDF documents found in {self.pdf_dir}")
            return
            
        print(f"Found {len(documents)} document chunks")
        
        # Split documents
        print("Splitting documents...")
        split_docs = self.pdf_loader.split_documents(documents)
        print(f"Created {len(split_docs)} document chunks")
        
        # Create vector store
        print("Creating vector store (this might take a while)...")
        self.vector_store.create_vector_store(split_docs)
        print("Vector store created successfully")
        
    def verify_answer(self, question: str, user_answer: str, k: int = 5) -> dict:
        """Verify if user's answer is supported by evidence in PDFs.
        
        Args:
            question: The question being asked
            user_answer: User's answer to evaluate
            k: Number of relevant documents to retrieve
            
        Returns:
            Dictionary with evaluation results
        """
        if self.use_agent:
            return self._verify_with_agent(question, user_answer, k)
        else:
            return self._verify_simple(question, user_answer, k)
    
    def _verify_simple(self, question: str, user_answer: str, k: int = 5) -> dict:
        """Simple verification using direct search.
        
        Args:
            question: The question being asked
            user_answer: User's answer to evaluate
            k: Number of relevant documents to retrieve
            
        Returns:
            Dictionary with evaluation results
        """
        print(f"Searching for relevant documents for: {question}")
        relevant_docs = self.vector_store.similarity_search(question, k=k)
        
        print(f"Found {len(relevant_docs)} relevant document chunks")
        print("Evaluating evidence...")
        
        is_supported, reasoning, evidence_used = self.evaluator.evaluate_evidence(
            question, user_answer, relevant_docs
        )
        
        # Record the evaluation
        file_path = self.recorder.record_evaluation(
            question, user_answer, is_supported, reasoning, evidence_used
        )
        
        print(f"Evaluation recorded to: {file_path}")
        
        return {
            "question": question,
            "user_answer": user_answer,
            "is_supported": is_supported,
            "reasoning": reasoning,
            "evidence_used": evidence_used,
            "sub_questions": None
        }
    
    def _verify_with_agent(self, question: str, user_answer: str, k_per_question: int = 3) -> dict:
        """Agent-based verification that breaks down complex questions.
        
        Args:
            question: The question being asked
            user_answer: User's answer to evaluate
            k_per_question: Number of relevant documents to retrieve per sub-question
            
        Returns:
            Dictionary with evaluation results
        """
        print(f"Analyzing question: {question}")
        print("Breaking down into sub-questions...")
        
        # Gather evidence for each sub-question
        evidence_items = self.agent.gather_evidence(
            question, user_answer, k_per_question=k_per_question
        )
        
        sub_questions = [item["sub_question"] for item in evidence_items]
        print(f"Generated {len(sub_questions)} sub-questions:")
        for i, sq in enumerate(sub_questions, 1):
            print(f"  {i}. {sq}")
        
        # Evaluate all evidence
        print("Evaluating evidence from all sub-questions...")
        is_supported, reasoning, evidence_used = self.agent.evaluate_all_evidence(
            question, user_answer, evidence_items
        )
        
        # Record the evaluation
        file_path = self.recorder.record_evaluation(
            question, user_answer, is_supported, reasoning, evidence_used
        )
        
        print(f"Evaluation recorded to: {file_path}")
        
        return {
            "question": question,
            "user_answer": user_answer,
            "is_supported": is_supported,
            "reasoning": reasoning,
            "evidence_used": evidence_used,
            "sub_questions": sub_questions
        }
        
def main():
    parser = argparse.ArgumentParser(description="PDF Evidence Verification System")
    parser.add_argument("--pdf-dir", default="PDF files", help="Directory containing PDF files")
    parser.add_argument("--model", default="llama3.1", help="Ollama model to use")
    parser.add_argument("--rebuild", action="store_true", help="Force rebuild vector store")
    parser.add_argument("--simple", action="store_true", help="Use simple approach without agents")
    
    subparsers = parser.add_subparsers(dest="command", help="Command to run")
    
    # Setup command
    setup_parser = subparsers.add_parser("setup", help="Set up the system")
    
    # Verify command
    verify_parser = subparsers.add_parser("verify", help="Verify user answer")
    verify_parser.add_argument("--question", required=True, help="Question to answer")
    verify_parser.add_argument("--answer", required=True, help="User's answer to verify")
    verify_parser.add_argument("--k", type=int, default=3, help="Number of documents to retrieve per sub-question")
    
    # Interactive command
    interactive_parser = subparsers.add_parser("interactive", help="Interactive mode")
    
    args = parser.parse_args()
    
    # Initialize the system
    verifier = PDFEvidenceVerifier(
        pdf_dir=args.pdf_dir,
        model_name=args.model,
        use_agent=not args.simple
    )
    
    if args.command == "setup" or args.rebuild:
        verifier.setup(force_rebuild=args.rebuild)
    
    elif args.command == "verify":
        # Make sure vector store exists
        if not os.path.exists(verifier.vector_store.persist_directory):
            print("Vector store not found. Running setup...")
            verifier.setup()
            
        # Verify the answer
        result = verifier.verify_answer(
            question=args.question,
            user_answer=args.answer,
            k=args.k
        )
        
        # Print the result
        print("\n===== Verification Result =====")
        print(f"Question: {result['question']}")
        print(f"User Answer: {result['user_answer']}")
        
        # If using agent-based approach, print sub-questions
        if result['sub_questions']:
            print("\nSub-Questions:")
            for i, sq in enumerate(result['sub_questions'], 1):
                print(f"  {i}. {sq}")
                
        print(f"\nVerdict: {'SUPPORTED' if result['is_supported'] else 'NOT SUPPORTED'}")
        print(f"Reasoning: {result['reasoning']}")
        print("\nEvidence Used:")
        for evidence in result['evidence_used']:
            print(f"- {evidence}")
    
    elif args.command == "interactive":
        # Make sure vector store exists
        if not os.path.exists(verifier.vector_store.persist_directory):
            print("Vector store not found. Running setup...")
            verifier.setup()
            
        print("Interactive mode - Enter 'exit' to quit")
        print(f"Using {'agent-based' if verifier.use_agent else 'simple'} approach")
        
        while True:
            question = input("\nEnter the question: ")
            if question.lower() == "exit":
                break
                
            user_answer = input("Enter the user's answer: ")
            if user_answer.lower() == "exit":
                break
                
            # Verify the answer
            result = verifier.verify_answer(
                question=question,
                user_answer=user_answer
            )
            
            # Print the result
            print("\n===== Verification Result =====")
            
            # If using agent-based approach, print sub-questions
            if result['sub_questions']:
                print("Sub-Questions:")
                for i, sq in enumerate(result['sub_questions'], 1):
                    print(f"  {i}. {sq}")
            
            print(f"\nVerdict: {'SUPPORTED' if result['is_supported'] else 'NOT SUPPORTED'}")
            print(f"Reasoning: {result['reasoning']}")
            print("\nEvidence Used:")
            for evidence in result['evidence_used']:
                print(f"- {evidence}")
    
    else:
        parser.print_help()
        
if __name__ == "__main__":
    main() 