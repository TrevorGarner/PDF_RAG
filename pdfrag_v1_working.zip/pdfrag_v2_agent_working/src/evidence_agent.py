from typing import List, Dict, Any, Tuple
from langchain.schema import Document
from langchain_ollama import OllamaLLM
from langchain.prompts import PromptTemplate
from langchain.chains import LLMChain

from question_decomposer import QuestionDecomposer
from vector_store import VectorStore

class EvidenceAgent:
    def __init__(self, vector_store: VectorStore, model_name: str = "llama3.1"):
        """Initialize the evidence agent.
        
        Args:
            vector_store: Vector store for searching documents
            model_name: Name of the Ollama model to use
        """
        self.vector_store = vector_store
        self.llm = OllamaLLM(model=model_name)
        self.question_decomposer = QuestionDecomposer(model_name=model_name)
        
    def gather_evidence(self, question: str, user_answer: str, k_per_question: int = 3) -> List[Dict[str, Any]]:
        """Gather evidence for each sub-question.
        
        Args:
            question: Original question
            user_answer: User's answer
            k_per_question: Number of documents to retrieve per sub-question
            
        Returns:
            List of evidence items with sub-question and relevant documents
        """
        # Decompose the question into sub-questions
        sub_questions = self.question_decomposer.decompose_question(question, user_answer)
        
        evidence_items = []
        all_docs = []
        
        # Gather evidence for each sub-question
        for sub_question in sub_questions:
            # Search for relevant documents
            relevant_docs = self.vector_store.similarity_search(sub_question, k=k_per_question)
            
            # Store documents with their relevance to the sub-question
            evidence_items.append({
                "sub_question": sub_question,
                "documents": relevant_docs
            })
            
            # Add to the overall list of documents
            all_docs.extend(relevant_docs)
            
        return evidence_items
        
    def analyze_sub_question_evidence(self, sub_question: str, user_answer: str, documents: List[Document]) -> Dict[str, Any]:
        """Analyze evidence for a single sub-question.
        
        Args:
            sub_question: The sub-question to analyze
            user_answer: User's answer to the original question
            documents: List of relevant documents for this sub-question
            
        Returns:
            Dictionary with analysis results
        """
        # Extract text from documents
        evidence_texts = [doc.page_content for doc in documents]
        combined_evidence = "\n\n".join(evidence_texts)
        
        template = """
        You are an objective evidence evaluator analyzing a specific aspect of a question.
        
        Sub-Question: {sub_question}
        
        User's Answer to the Original Question: {user_answer}
        
        Evidence from documents:
        {evidence}
        
        Your task is to determine if the evidence supports the user's answer specifically in relation to this sub-question.
        
        First, analyze the evidence carefully. Then, determine if the evidence supports the user's answer for this specific aspect.
        
        Format your response as follows:
        VERDICT: [SUPPORTED or PARTIALLY SUPPORTED or NOT SUPPORTED or INSUFFICIENT EVIDENCE]
        REASONING: [Your detailed reasoning]
        RELEVANT EVIDENCE: [List specific pieces of evidence used in your evaluation]
        """
        
        prompt = PromptTemplate(
            template=template,
            input_variables=["sub_question", "user_answer", "evidence"]
        )
        
        chain = LLMChain(llm=self.llm, prompt=prompt)
        result = chain.invoke({
            "sub_question": sub_question,
            "user_answer": user_answer,
            "evidence": combined_evidence
        })
        
        response_text = result["text"].strip() if "text" in result else str(result)
        
        # Parse the verdict
        verdict = "UNKNOWN"
        if "VERDICT: SUPPORTED" in response_text:
            verdict = "SUPPORTED"
        elif "VERDICT: PARTIALLY SUPPORTED" in response_text:
            verdict = "PARTIALLY SUPPORTED"
        elif "VERDICT: NOT SUPPORTED" in response_text:
            verdict = "NOT SUPPORTED"
        elif "VERDICT: INSUFFICIENT EVIDENCE" in response_text:
            verdict = "INSUFFICIENT EVIDENCE"
        
        # Parse reasoning
        reasoning_parts = response_text.split("REASONING:")
        reasoning = reasoning_parts[1].split("RELEVANT EVIDENCE:")[0].strip() if len(reasoning_parts) > 1 else ""
        
        # Parse relevant evidence
        evidence_parts = response_text.split("RELEVANT EVIDENCE:")
        evidence_used = evidence_parts[1].strip() if len(evidence_parts) > 1 else ""
        
        # Convert to list
        evidence_list = [e.strip() for e in evidence_used.split("\n") if e.strip()]
        
        return {
            "sub_question": sub_question,
            "verdict": verdict,
            "reasoning": reasoning,
            "evidence_used": evidence_list
        }
    
    def evaluate_all_evidence(self, question: str, user_answer: str, evidence_items: List[Dict[str, Any]]) -> Tuple[bool, str, List[str]]:
        """Evaluate all evidence to determine if it supports the user's answer.
        
        Args:
            question: Original question
            user_answer: User's answer
            evidence_items: List of evidence items with analysis results
            
        Returns:
            Tuple containing:
            - Boolean indicating if evidence supports the answer
            - Reasoning for the evaluation
            - List of evidence excerpts used
        """
        # Analyze each sub-question's evidence
        sub_question_analyses = []
        for item in evidence_items:
            analysis = self.analyze_sub_question_evidence(
                item["sub_question"], 
                user_answer, 
                item["documents"]
            )
            sub_question_analyses.append(analysis)
        
        # Combine all analyses for final evaluation
        sub_question_results = "\n\n".join([
            f"Sub-Question: {analysis['sub_question']}\n"
            f"Verdict: {analysis['verdict']}\n"
            f"Reasoning: {analysis['reasoning']}"
            for analysis in sub_question_analyses
        ])
        
        template = """
        You are a final evidence evaluator analyzing results from multiple sub-questions.
        
        Original Question: {question}
        
        User's Answer: {user_answer}
        
        Analysis of Sub-Questions:
        {sub_question_results}
        
        Your task is to make a final determination on whether the overall evidence supports the user's answer to the original question.
        
        Be objective and consider the strength of evidence for each sub-question. Some sub-questions may be more critical than others.
        
        Format your response as follows:
        FINAL VERDICT: [SUPPORTED or NOT SUPPORTED]
        REASONING: [Your detailed reasoning explaining how you weighed the different sub-question results]
        KEY EVIDENCE: [List the most important pieces of evidence that led to your conclusion]
        """
        
        prompt = PromptTemplate(
            template=template,
            input_variables=["question", "user_answer", "sub_question_results"]
        )
        
        chain = LLMChain(llm=self.llm, prompt=prompt)
        result = chain.invoke({
            "question": question,
            "user_answer": user_answer,
            "sub_question_results": sub_question_results
        })
        
        response_text = result["text"].strip() if "text" in result else str(result)
        
        # Parse final verdict
        is_supported = "FINAL VERDICT: SUPPORTED" in response_text
        
        # Parse reasoning
        reasoning_parts = response_text.split("REASONING:")
        reasoning = reasoning_parts[1].split("KEY EVIDENCE:")[0].strip() if len(reasoning_parts) > 1 else ""
        
        # Parse key evidence
        evidence_parts = response_text.split("KEY EVIDENCE:")
        evidence_used = evidence_parts[1].strip() if len(evidence_parts) > 1 else ""
        
        # Convert to list
        evidence_list = [e.strip() for e in evidence_used.split("\n") if e.strip()]
        
        # Collect all evidence used across sub-questions for detail
        all_evidence = []
        for analysis in sub_question_analyses:
            all_evidence.extend(analysis["evidence_used"])
        
        # If no key evidence was provided, use all evidence
        if not evidence_list:
            evidence_list = all_evidence
        
        return is_supported, reasoning, evidence_list 