# PDF Evidence Verification System

A system that analyzes whether a user's response to a question is supported by evidence found in PDF documents.

## Features

- Load and process PDF documents
- Create embeddings and vector database for efficient searching using Ollama embeddings
- **NEW**: Agent-based approach that breaks down complex questions into sub-questions
- Advanced evidence evaluation that considers multiple aspects of complex questions
- Evaluate if a user's answer is supported by evidence from PDFs
- Record evaluation results for later reference
- Interactive command-line interface

## Requirements

- Python 3.8+
- Ollama with Llama3.1 model installed and running locally (used for both LLM and embeddings)
- PDF files in the "PDF files" directory

## Installation

1. Clone this repository
2. Install the required dependencies:

```bash
pip install -r requirements.txt
```

3. Ensure Ollama is installed and running with Llama3.1 model:

```bash
# Install Ollama from https://ollama.ai/
# Run Ollama server
ollama serve

# In another terminal, pull the Llama3.1 model
ollama pull llama3.1

# For best embedding results, also pull mxbai-embed-large
ollama pull mxbai-embed-large
```

## Usage

### Setup

Before using the system, you need to set up the vector database:

```bash
python src/main.py setup
```

This will:
1. Load all PDF files from the "PDF files" directory
2. Process and split the documents into chunks
3. Create a vector database for efficient searching

### Verify an Answer

To verify if a user's answer is supported by evidence:

```bash
python src/main.py verify --question "What is climate change?" --answer "Climate change is caused by human activities."
```

By default, the system uses the agent-based approach which breaks down complex questions into sub-questions. 

To use the simple approach instead:

```bash
python src/main.py verify --simple --question "What is climate change?" --answer "Climate change is caused by human activities."
```

### Interactive Mode

For repeated verifications, use the interactive mode:

```bash
python src/main.py interactive
```

This will prompt you for questions and answers, and provide verification results.

### Additional Options

- `--pdf-dir PATH`: Specify a different directory for PDF files (default: "PDF files")
- `--model MODEL`: Specify a different Ollama model (default: "llama3.1")
- `--rebuild`: Force rebuild the vector database
- `--simple`: Use the simple approach without breaking questions into sub-questions
- `--k NUM`: Number of relevant documents to retrieve per sub-question (default: 3)

## How It Works

### Agent-Based Approach (Default)

The system uses a sophisticated agent-based approach for complex questions:

1. **Question Decomposition**: The system breaks down complex questions into 2-5 simpler sub-questions
2. **Evidence Gathering**: For each sub-question, the system retrieves relevant documents
3. **Sub-Question Analysis**: Each sub-question is analyzed individually with its evidence
4. **Holistic Evaluation**: The system combines all sub-question analyses for a final verdict

This approach provides more thorough and nuanced evaluations, especially for complex topics.

### Simple Approach

For simpler questions, you can use the `--simple` flag to use a direct approach:

1. Search for relevant documents for the main question
2. Evaluate if the evidence supports the user's answer

## Output

The system will produce:
1. Terminal output with verification results
2. JSON files in the "evaluation_results" directory containing detailed results

## Example with Agent-Based Approach

```bash
python src/main.py verify --question "What are the causes and effects of climate change, and how can it be mitigated?" --answer "Climate change is caused by greenhouse gas emissions, leads to rising sea levels and extreme weather, and can be mitigated through renewable energy and carbon capture."
```

Output:
```
Analyzing question: What are the causes and effects of climate change, and how can it be mitigated?
Breaking down into sub-questions...
Generated 3 sub-questions:
  1. What are the main causes of climate change?
  2. What are the major effects of climate change?
  3. What are effective methods to mitigate climate change?
Evaluating evidence from all sub-questions...
Evaluation recorded to: evaluation_results/evaluation_20230524_123045.json

===== Verification Result =====
Question: What are the causes and effects of climate change, and how can it be mitigated?
User Answer: Climate change is caused by greenhouse gas emissions, leads to rising sea levels and extreme weather, and can be mitigated through renewable energy and carbon capture.

Sub-Questions:
  1. What are the main causes of climate change?
  2. What are the major effects of climate change?
  3. What are effective methods to mitigate climate change?

Verdict: SUPPORTED
Reasoning: The evidence from the documents strongly supports all three components of the user's answer. The documents confirm that greenhouse gas emissions are the primary cause of climate change, that rising sea levels and extreme weather are significant effects, and that renewable energy and carbon capture are viable mitigation strategies.

Evidence Used:
- "Human activities are continuing to affect the Earth's energy budget by changing the emissions and resulting atmospheric concentrations of radiatively important gases and aerosols and by changing land surface properties."
- "Global mean sea level has risen by 0.19 [0.17 to 0.21] m over the period 1901 to 2010."
- "Climate change impacts are expected to exacerbate poverty in most developing countries and create new poverty pockets in countries with increasing inequality."
- "Many renewable energy technologies have demonstrated substantial performance improvements and cost reductions, and a growing number of renewable energy technologies have achieved a level of maturity to enable deployment at significant scale."
- "Carbon capture and storage (CCS) technologies could reduce the lifecycle GHG emissions of fossil fuel power plants."
``` 