# PDF Evidence Verification System

A system that analyzes whether a user's response to a question is supported by evidence found in PDF documents.

## Features

- Load and process PDF documents
- Create embeddings and vector database for efficient searching using Ollama embeddings
- Evaluate if a user's answer is supported by evidence from PDFs
- Record evaluation results for later reference
- Interactive command-line interface

## Requirements

- Python 3.8+
- Ollama with Llama3.1 model installed and running locally (used for both LLM and embeddings)
- PDF files in the "PDF files" directory

## Installation

1. Clone this repository
2. Install the required dependencies:

```bash
pip install -r requirements.txt
```

3. Ensure Ollama is installed and running with Llama3.1 model:

```bash
# Install Ollama from https://ollama.ai/
# Run Ollama server
ollama serve

# In another terminal, pull the Llama3.1 model
ollama pull llama3.1
```

## Usage

### Setup

Before using the system, you need to set up the vector database:

```bash
python src/main.py setup
```

This will:
1. Load all PDF files from the "PDF files" directory
2. Process and split the documents into chunks
3. Create a vector database for efficient searching

### Verify an Answer

To verify if a user's answer is supported by evidence:

```bash
python src/main.py verify --question "What is climate change?" --answer "Climate change is caused by human activities."
```

### Interactive Mode

For repeated verifications, use the interactive mode:

```bash
python src/main.py interactive
```

This will prompt you for questions and answers, and provide verification results.

### Additional Options

- `--pdf-dir PATH`: Specify a different directory for PDF files (default: "PDF files")
- `--model MODEL`: Specify a different Ollama model (default: "llama3.1")
- `--rebuild`: Force rebuild the vector database
- `--k NUM`: Number of relevant documents to retrieve (default: 5)

## Output

The system will produce:
1. Terminal output with verification results
2. JSON files in the "evaluation_results" directory containing detailed results

## Example

```bash
python src/main.py verify --question "What is the main cause of climate change?" --answer "The main cause of climate change is greenhouse gas emissions from human activities."
```

Output:
```
Searching for relevant documents for: What is the main cause of climate change?
Found 5 relevant document chunks
Evaluating evidence...
Evaluation recorded to: evaluation_results/evaluation_20230524_123045.json

===== Verification Result =====
Question: What is the main cause of climate change?
User Answer: The main cause of climate change is greenhouse gas emissions from human activities.
Verdict: SUPPORTED
Reasoning: The evidence clearly states that human activities, particularly the burning of fossil fuels, are the dominant cause of climate change through greenhouse gas emissions.
Evidence Used:
- "Human influence on the climate system is clear, and recent anthropogenic emissions of greenhouse gases are the highest in history."
- "The evidence for human influence on the climate system has grown since the IPCC Fourth Assessment Report."
- "Human activities are continuing to affect the Earth's energy budget by changing the emissions and resulting atmospheric concentrations of radiatively important gases and aerosols and by changing land surface properties."
``` 