import os
from typing import List, Dict
from langchain_community.document_loaders import PyPDFLoader
from langchain.schema import Document
from langchain.text_splitter import RecursiveCharacterTextSplitter

class PDFDocumentLoader:
    def __init__(self, pdf_dir: str):
        """Initialize with the directory containing PDF files.
        
        Args:
            pdf_dir: Path to directory containing PDF files
        """
        self.pdf_dir = pdf_dir
        
    def load_documents(self) -> List[Document]:
        """Load all PDF documents from the specified directory.
        
        Returns:
            List of Document objects
        """
        documents = []
        
        if not os.path.exists(self.pdf_dir):
            raise FileNotFoundError(f"PDF directory not found: {self.pdf_dir}")
            
        for filename in os.listdir(self.pdf_dir):
            if filename.lower().endswith('.pdf'):
                file_path = os.path.join(self.pdf_dir, filename)
                loader = PyPDFLoader(file_path)
                documents.extend(loader.load())
                
        return documents
    
    def split_documents(self, documents: List[Document], chunk_size: int = 1000, chunk_overlap: int = 200) -> List[Document]:
        """Split documents into chunks for processing.
        
        Args:
            documents: List of documents to split
            chunk_size: Size of each chunk
            chunk_overlap: Overlap between chunks
            
        Returns:
            List of split Document objects
        """
        text_splitter = RecursiveCharacterTextSplitter(
            chunk_size=chunk_size,
            chunk_overlap=chunk_overlap,
            length_function=len
        )
        
        return text_splitter.split_documents(documents) 