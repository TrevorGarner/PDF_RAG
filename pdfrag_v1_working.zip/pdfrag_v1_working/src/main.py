import os
import argparse
from typing import List, Optional

from pdf_loader import PDFDocumentLoader
from vector_store import VectorStore
from evidence_evaluator import EvidenceEvaluator
from response_recorder import ResponseRecorder

class PDFEvidenceVerifier:
    def __init__(
        self,
        pdf_dir: str = "PDF files",
        model_name: str = "llama3.1",
        vector_store_dir: str = "chroma_db",
        output_dir: str = "evaluation_results"
    ):
        """Initialize the PDF evidence verification system.
        
        Args:
            pdf_dir: Directory containing PDF files
            model_name: Name of Ollama model to use
            vector_store_dir: Directory to store vector database
            output_dir: Directory to store evaluation results
        """
        self.pdf_dir = pdf_dir
        self.model_name = model_name
        
        # Initialize components
        self.pdf_loader = PDFDocumentLoader(pdf_dir)
        self.vector_store = VectorStore(persist_directory=vector_store_dir)
        self.evaluator = EvidenceEvaluator(model_name=model_name)
        self.recorder = ResponseRecorder(output_dir=output_dir)
        
    def setup(self, force_rebuild: bool = False) -> None:
        """Set up the system by loading documents and creating vector store.
        
        Args:
            force_rebuild: Whether to force rebuilding the vector store
        """
        # Try to load existing vector store
        if not force_rebuild and self.vector_store.load_vector_store():
            print(f"Loaded existing vector store.")
            return
            
        print(f"Loading PDF documents from {self.pdf_dir}...")
        documents = self.pdf_loader.load_documents()
        
        if not documents:
            print(f"No PDF documents found in {self.pdf_dir}")
            return
            
        print(f"Found {len(documents)} document chunks")
        
        # Split documents
        print("Splitting documents...")
        split_docs = self.pdf_loader.split_documents(documents)
        print(f"Created {len(split_docs)} document chunks")
        
        # Create vector store
        print("Creating vector store (this might take a while)...")
        self.vector_store.create_vector_store(split_docs)
        print("Vector store created successfully")
        
    def verify_answer(self, question: str, user_answer: str, k: int = 5) -> dict:
        """Verify if user's answer is supported by evidence in PDFs.
        
        Args:
            question: The question being asked
            user_answer: User's answer to evaluate
            k: Number of relevant documents to retrieve
            
        Returns:
            Dictionary with evaluation results
        """
        print(f"Searching for relevant documents for: {question}")
        relevant_docs = self.vector_store.similarity_search(question, k=k)
        
        print(f"Found {len(relevant_docs)} relevant document chunks")
        print("Evaluating evidence...")
        
        is_supported, reasoning, evidence_used = self.evaluator.evaluate_evidence(
            question, user_answer, relevant_docs
        )
        
        # Record the evaluation
        file_path = self.recorder.record_evaluation(
            question, user_answer, is_supported, reasoning, evidence_used
        )
        
        print(f"Evaluation recorded to: {file_path}")
        
        return {
            "question": question,
            "user_answer": user_answer,
            "is_supported": is_supported,
            "reasoning": reasoning,
            "evidence_used": evidence_used
        }
        
def main():
    parser = argparse.ArgumentParser(description="PDF Evidence Verification System")
    parser.add_argument("--pdf-dir", default="PDF files", help="Directory containing PDF files")
    parser.add_argument("--model", default="llama3.1", help="Ollama model to use")
    parser.add_argument("--rebuild", action="store_true", help="Force rebuild vector store")
    
    subparsers = parser.add_subparsers(dest="command", help="Command to run")
    
    # Setup command
    setup_parser = subparsers.add_parser("setup", help="Set up the system")
    
    # Verify command
    verify_parser = subparsers.add_parser("verify", help="Verify user answer")
    verify_parser.add_argument("--question", required=True, help="Question to answer")
    verify_parser.add_argument("--answer", required=True, help="User's answer to verify")
    verify_parser.add_argument("--k", type=int, default=5, help="Number of documents to retrieve")
    
    # Interactive command
    interactive_parser = subparsers.add_parser("interactive", help="Interactive mode")
    
    args = parser.parse_args()
    
    # Initialize the system
    verifier = PDFEvidenceVerifier(
        pdf_dir=args.pdf_dir,
        model_name=args.model
    )
    
    if args.command == "setup" or args.rebuild:
        verifier.setup(force_rebuild=args.rebuild)
    
    elif args.command == "verify":
        # Make sure vector store exists
        if not os.path.exists(verifier.vector_store.persist_directory):
            print("Vector store not found. Running setup...")
            verifier.setup()
            
        # Verify the answer
        result = verifier.verify_answer(
            question=args.question,
            user_answer=args.answer,
            k=args.k
        )
        
        # Print the result
        print("\n===== Verification Result =====")
        print(f"Question: {result['question']}")
        print(f"User Answer: {result['user_answer']}")
        print(f"Verdict: {'SUPPORTED' if result['is_supported'] else 'NOT SUPPORTED'}")
        print(f"Reasoning: {result['reasoning']}")
        print("Evidence Used:")
        for evidence in result['evidence_used']:
            print(f"- {evidence}")
    
    elif args.command == "interactive":
        # Make sure vector store exists
        if not os.path.exists(verifier.vector_store.persist_directory):
            print("Vector store not found. Running setup...")
            verifier.setup()
            
        print("Interactive mode - Enter 'exit' to quit")
        
        while True:
            question = input("\nEnter the question: ")
            if question.lower() == "exit":
                break
                
            user_answer = input("Enter the user's answer: ")
            if user_answer.lower() == "exit":
                break
                
            # Verify the answer
            result = verifier.verify_answer(
                question=question,
                user_answer=user_answer
            )
            
            # Print the result
            print("\n===== Verification Result =====")
            print(f"Verdict: {'SUPPORTED' if result['is_supported'] else 'NOT SUPPORTED'}")
            print(f"Reasoning: {result['reasoning']}")
            print("Evidence Used:")
            for evidence in result['evidence_used']:
                print(f"- {evidence}")
    
    else:
        parser.print_help()
        
if __name__ == "__main__":
    main() 