# PDF Evidence Verification System
# A system that analyzes whether evidence in PDFs supports a user's answer. 