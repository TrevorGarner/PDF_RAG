from typing import List, Dict, Any, Tuple
from langchain.schema import Document
from langchain_ollama import OllamaEmbeddings, OllamaLLM   
from langchain.prompts import PromptTemplate
from langchain.chains import LLMChain

class EvidenceEvaluator:
    def __init__(self, model_name: str = "llama3.1"):
        """Initialize with the LLM model for evaluation.
        
        Args:
            model_name: Name of the Ollama model to use
        """
        self.llm = OllamaLLM(model=model_name)
        
    def evaluate_evidence(self, question: str, user_answer: str, evidence_docs: List[Document]) -> Tuple[bool, str, List[str]]:
        """Evaluate if the evidence supports the user's answer.
        
        Args:
            question: Original question
            user_answer: User's answer to evaluate
            evidence_docs: List of relevant document chunks
            
        Returns:
            Tuple containing:
            - Boolean indicating if evidence supports the answer
            - Reasoning for the evaluation
            - List of evidence excerpts used
        """
        # Extract text from evidence documents
        evidence_texts = [doc.page_content for doc in evidence_docs]
        combined_evidence = "\n\n".join(evidence_texts)
        
        # Create a prompt for the LLM
        template = """
        You are an objective evidence evaluator. Your task is to determine if the evidence from documents supports a user's answer to a question.
        
        Question: {question}
        
        User's Answer: {user_answer}
        
        Evidence from documents:
        {evidence}
        
        First, analyze the evidence carefully. Then, determine if the evidence supports the user's answer.
        If the evidence supports the answer, respond with 'SUPPORTED' followed by your reasoning and specific evidence used.
        If the evidence does not support the answer, respond with 'NOT SUPPORTED' followed by your reasoning and explanation.
        
        Your response should follow this format:
        VERDICT: [SUPPORTED or NOT SUPPORTED]
        REASONING: [Your detailed reasoning]
        EVIDENCE USED: [List specific pieces of evidence used in your evaluation]
        """
        
        prompt = PromptTemplate(
            template=template,
            input_variables=["question", "user_answer", "evidence"]
        )
        
        # Create and run the chain
        chain = LLMChain(llm=self.llm, prompt=prompt)
        result = chain.invoke({
            "question": question,
            "user_answer": user_answer,
            "evidence": combined_evidence
        })
        
        # Parse the result
        response_text = result["text"].strip() if "text" in result else str(result)
        
        # Extract verdict
        if "VERDICT: SUPPORTED" in response_text:
            is_supported = True
        else:
            is_supported = False
            
        # Extract reasoning
        reasoning_parts = response_text.split("REASONING:")
        reasoning = reasoning_parts[1].split("EVIDENCE USED:")[0].strip() if len(reasoning_parts) > 1 else ""
        
        # Extract evidence used
        evidence_parts = response_text.split("EVIDENCE USED:")
        evidence_used = evidence_parts[1].strip() if len(evidence_parts) > 1 else ""
        
        # Convert to list of evidence points
        evidence_list = [e.strip() for e in evidence_used.split("\n") if e.strip()]
        
        return is_supported, reasoning, evidence_list 