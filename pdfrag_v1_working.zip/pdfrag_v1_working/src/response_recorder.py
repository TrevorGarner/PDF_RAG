import os
import json
from typing import List, Dict, Any
from datetime import datetime

class ResponseRecorder:
    def __init__(self, output_dir: str = "evaluation_results"):
        """Initialize with output directory.
        
        Args:
            output_dir: Directory to save evaluation results
        """
        self.output_dir = output_dir
        os.makedirs(output_dir, exist_ok=True)
        
    def record_evaluation(
        self, 
        question: str, 
        user_answer: str, 
        is_supported: bool, 
        reasoning: str, 
        evidence_used: List[str]
    ) -> str:
        """Record the evaluation results to a JSON file.
        
        Args:
            question: Original question
            user_answer: User's answer
            is_supported: Whether evidence supports the answer
            reasoning: Reasoning for the evaluation
            evidence_used: List of evidence used
            
        Returns:
            Path to the saved file
        """
        # Create evaluation record
        evaluation = {
            "timestamp": datetime.now().isoformat(),
            "question": question,
            "user_answer": user_answer,
            "is_supported": is_supported,
            "reasoning": reasoning,
            "evidence_used": evidence_used
        }
        
        # Generate filename based on timestamp
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        filename = f"evaluation_{timestamp}.json"
        file_path = os.path.join(self.output_dir, filename)
        
        # Write to file
        with open(file_path, 'w', encoding='utf-8') as f:
            json.dump(evaluation, f, indent=2, ensure_ascii=False)
            
        return file_path
        
    def get_evaluation_history(self) -> List[Dict[str, Any]]:
        """Get history of all recorded evaluations.
        
        Returns:
            List of evaluation records
        """
        history = []
        
        if not os.path.exists(self.output_dir):
            return history
            
        for filename in os.listdir(self.output_dir):
            if filename.endswith('.json'):
                file_path = os.path.join(self.output_dir, filename)
                try:
                    with open(file_path, 'r', encoding='utf-8') as f:
                        evaluation = json.load(f)
                        history.append(evaluation)
                except Exception as e:
                    print(f"Error reading {file_path}: {e}")
                    
        # Sort by timestamp
        history.sort(key=lambda x: x.get('timestamp', ''))
        return history 