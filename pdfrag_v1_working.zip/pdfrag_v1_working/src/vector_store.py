from typing import List, Optional
import os
from langchain.schema import Document
from langchain_community.vectorstores import Chroma
from langchain_ollama import OllamaEmbeddings

class VectorStore:
    def __init__(self, persist_directory: str = "chroma_db", model_name: str = "mxbai-embed-large"):
        """Initialize the vector store with embedding model.
        
        Args:
            persist_directory: Directory to persist vector store
            model_name: Name of the Ollama model to use
        """
        self.persist_directory = persist_directory
        # Using Ollama for embeddings
        self.embeddings = OllamaEmbeddings(model=model_name)
        self.vector_db = None
        
    def create_vector_store(self, documents: List[Document]) -> None:
        """Create a vector store from documents.
        
        Args:
            documents: List of documents to index
        """
        if not documents:
            raise ValueError("No documents provided to index")
            
        # Ensure the persist directory exists
        os.makedirs(self.persist_directory, exist_ok=True)
        
        # Create and persist the vector store
        self.vector_db = Chroma.from_documents(
            documents=documents,
            embedding=self.embeddings,
            persist_directory=self.persist_directory
        )
        self.vector_db.persist()
        
    def load_vector_store(self) -> bool:
        """Load an existing vector store if available.
        
        Returns:
            bool: True if loaded successfully, False otherwise
        """
        if os.path.exists(self.persist_directory):
            self.vector_db = Chroma(
                persist_directory=self.persist_directory,
                embedding_function=self.embeddings
            )
            return True
        return False
        
    def similarity_search(self, query: str, k: int = 4) -> List[Document]:
        """Perform similarity search on the vector store.
        
        Args:
            query: Query string
            k: Number of results to return
            
        Returns:
            List of relevant documents
        """
        if not self.vector_db:
            raise ValueError("Vector store not initialized. Call create_vector_store or load_vector_store first.")
            
        return self.vector_db.similarity_search(query, k=k) 