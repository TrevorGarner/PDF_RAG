#!/usr/bin/env python3
"""
Streamlit web interface for DataChat
"""

import os
import streamlit as st
import pandas as pd
from datachat import DataChat

# Add streamlit to requirements.txt
with open("requirements.txt", "a") as f:
    f.write("\nstreamlit==1.32.0\n")

def main():
    st.set_page_config(
        page_title="DataChat",
        page_icon="📊",
        layout="wide",
    )
    
    st.title("DataChat 📊")
    st.subheader("Talk to your CSV and Excel data using natural language")
    
    # Initialize session state
    if "chat" not in st.session_state:
        st.session_state.chat = None
    if "conversation" not in st.session_state:
        st.session_state.conversation = []
    if "df" not in st.session_state:
        st.session_state.df = None
    
    # Sidebar for configuration
    with st.sidebar:
        st.header("Configuration")
        
        # File upload
        uploaded_file = st.file_uploader("Upload a CSV or Excel file", type=["csv", "xlsx", "xls"])
        
        # Model selection
        model = st.text_input("Ollama Model", value="llama3", help="The Ollama model to use")
        
        # Max rows
        max_rows = st.slider("Max Context Rows", min_value=10, max_value=500, value=100, 
                            help="Maximum number of rows to include in the context")
        
        # Load sample data button
        if st.button("Load Sample Data"):
            sample_file = create_sample_data()
            st.session_state.chat = DataChat(
                file_path=sample_file,
                llm_model=model,
                max_context_rows=max_rows
            )
            st.session_state.df = st.session_state.chat.get_dataframe()
            st.session_state.conversation = []
            st.success(f"Loaded sample data: {sample_file}")
        
        # Reset conversation
        if st.button("Reset Conversation"):
            st.session_state.conversation = []
            if st.session_state.chat:
                st.session_state.chat.clear_conversation()
        
        # Reset filters
        if st.button("Reset Filters"):
            if st.session_state.chat:
                st.session_state.chat.reset_filters()
                st.session_state.df = st.session_state.chat.get_dataframe()
                st.success("Filters reset")
    
    # Process uploaded file
    if uploaded_file is not None:
        # Save the uploaded file to a temporary file
        file_path = os.path.join(".", uploaded_file.name)
        with open(file_path, "wb") as f:
            f.write(uploaded_file.getbuffer())
        
        # Initialize DataChat with the uploaded file
        st.session_state.chat = DataChat(
            file_path=file_path,
            llm_model=model,
            max_context_rows=max_rows
        )
        st.session_state.df = st.session_state.chat.get_dataframe()
        st.session_state.conversation = []
        st.success(f"Loaded file: {uploaded_file.name}")
    
    # Main content area
    col1, col2 = st.columns([3, 2])
    
    with col1:
        # Chat interface
        st.header("Chat with your data")
        
        # Display conversation
        for message in st.session_state.conversation:
            if message["role"] == "user":
                st.markdown(f"**You:** {message['content']}")
            else:
                st.markdown(f"**DataChat:** {message['content']}")
        
        # Input for new questions
        with st.form(key="question_form", clear_on_submit=True):
            user_question = st.text_area("Ask a question about your data:", height=100)
            submit_button = st.form_submit_button("Ask")
            
            if submit_button and user_question:
                if st.session_state.chat is None:
                    st.error("Please upload a file or load sample data first.")
                else:
                    # Add user question to conversation
                    st.session_state.conversation.append({"role": "user", "content": user_question})
                    
                    # Get response from DataChat
                    with st.spinner("Thinking..."):
                        response = st.session_state.chat.query(user_question)
                    
                    # Add response to conversation
                    st.session_state.conversation.append({"role": "assistant", "content": response})
                    
                    # Rerun to update the UI
                    st.experimental_rerun()
    
    with col2:
        # Data preview
        st.header("Data Preview")
        
        if st.session_state.df is not None:
            # Display dataframe info
            st.subheader("Dataframe Info")
            if st.session_state.chat:
                st.text(st.session_state.chat.get_dataframe_info())
            
            # Display dataframe preview
            st.subheader("Data Sample")
            st.dataframe(st.session_state.df.head(10), use_container_width=True)
            
            # Display column statistics
            st.subheader("Column Statistics")
            if st.session_state.df.select_dtypes(include=['number']).columns.any():
                st.write(st.session_state.df.describe())
        else:
            st.info("No data loaded. Please upload a file or load sample data.")


def create_sample_data(file_path="sample_data.csv"):
    """Create a sample CSV file for demonstration"""
    data = {
        "Name": ["Alice", "Bob", "Charlie", "David", "Emma", "Frank", "Grace", "Hannah", "Ian", "Julia"],
        "Age": [25, 32, 45, 28, 36, 52, 29, 41, 33, 37],
        "Department": ["Sales", "Engineering", "Marketing", "Sales", "HR", "Engineering", "Marketing", "HR", "Sales", "Engineering"],
        "Salary": [65000, 85000, 72000, 63000, 58000, 95000, 67000, 59000, 72000, 88000],
        "Years_Experience": [2, 5, 12, 3, 7, 15, 4, 9, 6, 8]
    }
    
    df = pd.DataFrame(data)
    df.to_csv(file_path, index=False)
    return file_path


if __name__ == "__main__":
    main() 