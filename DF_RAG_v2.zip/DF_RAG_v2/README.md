# DataChat

DataChat is a tool that allows users to interact with CSV and Excel data using natural language queries through an LLM (Large Language Model).

## Features

- Load data from CSV and Excel files
- Query data using natural language
- Fuzzy matching for column names and values
- Flexible LLM backend (currently using Ollama)

## Installation

1. Clone this repository
2. Install the required dependencies:
   ```
   pip install -r requirements.txt
   ```
3. Make sure you have Ollama installed and running locally (or configure a different LLM backend)

## Usage

```python
from datachat import DataChat

# Initialize with a data file
chat = DataChat("your_data.csv")  # or .xlsx

# Ask questions about your data
response = chat.query("What is the average age in the dataset?")
print(response)

# You can also load a different file
chat.load_data("another_file.xlsx")
```

## Configuration

You can configure the LLM backend by modifying the `.env` file or setting environment variables:

```
OLLAMA_BASE_URL=http://localhost:11434
OLLAMA_MODEL=llama3
```

## License

MIT 