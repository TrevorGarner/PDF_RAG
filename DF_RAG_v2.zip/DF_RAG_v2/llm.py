import os
import json
import requests
from typing import Dict, Any, Optional, List
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

class LLMBackend:
    """Base class for LLM backends"""
    
    def generate(self, prompt: str, system_prompt: Optional[str] = None, **kwargs) -> str:
        """Generate a response from the LLM"""
        raise NotImplementedError("Subclasses must implement this method")


class OllamaBackend(LLMBackend):
    """Ollama backend for LLM interactions"""
    
    def __init__(self, model: Optional[str] = None, base_url: Optional[str] = None):
        """
        Initialize the Ollama backend
        
        Args:
            model: The model to use (defaults to env var OLLAMA_MODEL or 'llama3')
            base_url: The base URL for the Ollama API (defaults to env var OLLAMA_BASE_URL or 'http://localhost:11434')
        """
        self.model = model or os.getenv("OLLAMA_MODEL", "llama3")
        self.base_url = base_url or os.getenv("OLLAMA_BASE_URL", "http://localhost:11434")
        self.api_url = f"{self.base_url}/api/generate"
    
    def generate(self, prompt: str, system_prompt: Optional[str] = None, **kwargs) -> str:
        """
        Generate a response from the Ollama LLM
        
        Args:
            prompt: The user prompt
            system_prompt: Optional system prompt to guide the model
            **kwargs: Additional parameters to pass to the Ollama API
            
        Returns:
            The generated text response
        """
        payload = {
            "model": self.model,
            "prompt": prompt,
            "stream": False,
            **kwargs
        }
        
        if system_prompt:
            payload["system"] = system_prompt
            
        try:
            response = requests.post(self.api_url, json=payload)
            response.raise_for_status()
            return response.json().get("response", "")
        except requests.RequestException as e:
            error_msg = f"Error communicating with Ollama: {str(e)}"
            print(error_msg)
            return error_msg


class LLMFactory:
    """Factory for creating LLM backends"""
    
    @staticmethod
    def create(backend_type: str = "ollama", **kwargs) -> LLMBackend:
        """
        Create an LLM backend
        
        Args:
            backend_type: The type of backend to create ('ollama' is currently the only supported type)
            **kwargs: Additional parameters to pass to the backend constructor
            
        Returns:
            An LLM backend instance
        """
        if backend_type.lower() == "ollama":
            return OllamaBackend(**kwargs)
        else:
            raise ValueError(f"Unsupported LLM backend type: {backend_type}") 