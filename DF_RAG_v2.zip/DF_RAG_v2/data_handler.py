import os
import pandas as pd
import numpy as np
from typing import Optional, Dict, List, Any, Tuple, Union
from fuzzywuzzy import process, fuzz


class DataHandler:
    """Handler for loading and processing data from CSV and Excel files"""
    
    def __init__(self, file_path: Optional[str] = None):
        """
        Initialize the data handler
        
        Args:
            file_path: Optional path to a data file to load
        """
        self.df = None
        self.file_path = None
        self.file_type = None
        self.metadata = {}
        
        if file_path:
            self.load_data(file_path)
    
    def load_data(self, file_path: str) -> bool:
        """
        Load data from a CSV or Excel file
        
        Args:
            file_path: Path to the data file
            
        Returns:
            True if loading was successful, False otherwise
        """
        if not os.path.exists(file_path):
            print(f"File not found: {file_path}")
            return False
        
        file_ext = os.path.splitext(file_path)[1].lower()
        
        try:
            if file_ext == '.csv':
                self.df = pd.read_csv(file_path)
                self.file_type = 'csv'
            elif file_ext in ['.xlsx', '.xls']:
                self.df = pd.read_excel(file_path)
                self.file_type = 'excel'
            else:
                print(f"Unsupported file type: {file_ext}")
                return False
            
            self.file_path = file_path
            self._generate_metadata()
            return True
        except Exception as e:
            print(f"Error loading data: {str(e)}")
            return False
    
    def _generate_metadata(self) -> None:
        """Generate metadata about the loaded dataframe"""
        if self.df is None:
            return
        
        # Basic metadata
        self.metadata = {
            'file_path': self.file_path,
            'file_type': self.file_type,
            'rows': len(self.df),
            'columns': list(self.df.columns),
            'dtypes': {col: str(dtype) for col, dtype in self.df.dtypes.items()},
            'sample': self.df.head(5).to_dict(orient='records'),
            'missing_values': self.df.isna().sum().to_dict(),
            'numeric_columns': list(self.df.select_dtypes(include=[np.number]).columns),
            'categorical_columns': list(self.df.select_dtypes(include=['object', 'category']).columns),
            'datetime_columns': list(self.df.select_dtypes(include=['datetime']).columns),
        }
        
        # Add summary statistics for numeric columns
        self.metadata['numeric_stats'] = {}
        for col in self.metadata['numeric_columns']:
            self.metadata['numeric_stats'][col] = {
                'min': float(self.df[col].min()) if not pd.isna(self.df[col].min()) else None,
                'max': float(self.df[col].max()) if not pd.isna(self.df[col].max()) else None,
                'mean': float(self.df[col].mean()) if not pd.isna(self.df[col].mean()) else None,
                'median': float(self.df[col].median()) if not pd.isna(self.df[col].median()) else None,
                'std': float(self.df[col].std()) if not pd.isna(self.df[col].std()) else None,
            }
        
        # Add value counts for categorical columns (limited to top 10)
        self.metadata['categorical_stats'] = {}
        for col in self.metadata['categorical_columns']:
            value_counts = self.df[col].value_counts().head(10).to_dict()
            self.metadata['categorical_stats'][col] = {str(k): int(v) for k, v in value_counts.items()}
    
    def get_dataframe_info(self) -> str:
        """
        Get a string representation of the dataframe info
        
        Returns:
            A string with information about the dataframe
        """
        if self.df is None:
            return "No data loaded"
        
        info = []
        info.append(f"File: {self.file_path} ({self.file_type})")
        info.append(f"Shape: {self.df.shape[0]} rows × {self.df.shape[1]} columns")
        info.append("Columns:")
        
        for col in self.df.columns:
            dtype = self.df[col].dtype
            missing = self.df[col].isna().sum()
            missing_pct = (missing / len(self.df)) * 100
            info.append(f"  - {col} ({dtype}): {missing} missing values ({missing_pct:.1f}%)")
        
        return "\n".join(info)
    
    def find_columns(self, query: str, threshold: int = 70) -> List[str]:
        """
        Find columns that match the query using fuzzy matching
        
        Args:
            query: The search query
            threshold: The minimum similarity score (0-100)
            
        Returns:
            A list of matching column names
        """
        if self.df is None or not self.df.columns.any():
            return []
        
        matches = process.extractBests(
            query, 
            self.df.columns, 
            scorer=fuzz.token_sort_ratio, 
            score_cutoff=threshold
        )
        
        return [match[0] for match in matches]
    
    def filter_dataframe(self, query: Dict[str, Any]) -> pd.DataFrame:
        """
        Filter the dataframe based on a query dictionary
        
        Args:
            query: A dictionary with column names as keys and filter values
            
        Returns:
            A filtered dataframe
        """
        if self.df is None:
            return pd.DataFrame()
        
        filtered_df = self.df.copy()
        
        for col, value in query.items():
            if col not in filtered_df.columns:
                # Try fuzzy matching
                matches = self.find_columns(col)
                if matches:
                    col = matches[0]
                else:
                    continue
            
            if isinstance(value, (list, tuple)):
                filtered_df = filtered_df[filtered_df[col].isin(value)]
            elif isinstance(value, dict):
                if 'min' in value and 'max' in value:
                    filtered_df = filtered_df[(filtered_df[col] >= value['min']) & 
                                             (filtered_df[col] <= value['max'])]
                elif 'min' in value:
                    filtered_df = filtered_df[filtered_df[col] >= value['min']]
                elif 'max' in value:
                    filtered_df = filtered_df[filtered_df[col] <= value['max']]
                elif 'contains' in value:
                    filtered_df = filtered_df[filtered_df[col].astype(str).str.contains(
                        value['contains'], case=False, na=False)]
            else:
                filtered_df = filtered_df[filtered_df[col] == value]
        
        return filtered_df
    
    def execute_query(self, query: str) -> Tuple[pd.DataFrame, Dict[str, Any]]:
        """
        Execute a pandas query on the dataframe
        
        Args:
            query: A pandas query string
            
        Returns:
            A tuple of (result_dataframe, query_info)
        """
        if self.df is None:
            return pd.DataFrame(), {"error": "No data loaded"}
        
        try:
            result = self.df.query(query)
            info = {
                "query": query,
                "rows_before": len(self.df),
                "rows_after": len(result),
                "columns": list(result.columns)
            }
            return result, info
        except Exception as e:
            return pd.DataFrame(), {"error": str(e), "query": query}
    
    def get_context_for_llm(self, max_rows: int = 100) -> Dict[str, Any]:
        """
        Get context information about the dataframe for the LLM
        
        Args:
            max_rows: Maximum number of rows to include in the sample
            
        Returns:
            A dictionary with context information
        """
        if self.df is None:
            return {"error": "No data loaded"}
        
        context = {
            "file_info": {
                "path": self.file_path,
                "type": self.file_type,
            },
            "dataframe_info": {
                "shape": self.df.shape,
                "columns": list(self.df.columns),
                "dtypes": {col: str(dtype) for col, dtype in self.df.dtypes.items()},
            },
            "sample_data": self.df.head(min(max_rows, len(self.df))).to_dict(orient='records'),
            "summary_stats": {}
        }
        
        # Add summary statistics for numeric columns
        numeric_cols = self.df.select_dtypes(include=[np.number]).columns
        if len(numeric_cols) > 0:
            context["summary_stats"]["numeric"] = self.df[numeric_cols].describe().to_dict()
        
        # Add value counts for categorical columns (limited to top 5 values)
        cat_cols = self.df.select_dtypes(include=['object', 'category']).columns
        if len(cat_cols) > 0:
            context["summary_stats"]["categorical"] = {}
            for col in cat_cols:
                context["summary_stats"]["categorical"][col] = self.df[col].value_counts().head(5).to_dict()
        
        return context 