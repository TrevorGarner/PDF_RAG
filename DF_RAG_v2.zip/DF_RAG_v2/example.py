#!/usr/bin/env python3
"""
Example script demonstrating how to use DataChat programmatically
"""

import os
import pandas as pd
from datachat import DataChat

# Create a sample DataFrame if no file is provided
def create_sample_data(file_path="sample_data.csv"):
    """Create a sample CSV file for demonstration"""
    data = {
        "Name": ["Alice", "Bob", "Charlie", "David", "Emma", "Frank", "Grace", "Hannah", "Ian", "Julia"],
        "Age": [25, 32, 45, 28, 36, 52, 29, 41, 33, 37],
        "Department": ["Sales", "Engineering", "Marketing", "Sales", "HR", "Engineering", "Marketing", "HR", "Sales", "Engineering"],
        "Salary": [65000, 85000, 72000, 63000, 58000, 95000, 67000, 59000, 72000, 88000],
        "Years_Experience": [2, 5, 12, 3, 7, 15, 4, 9, 6, 8]
    }
    
    df = pd.DataFrame(data)
    df.to_csv(file_path, index=False)
    print(f"Created sample data file: {file_path}")
    return file_path


def main():
    # Check if sample data exists, create it if not
    sample_file = "sample_data.csv"
    if not os.path.exists(sample_file):
        create_sample_data(sample_file)
    
    # Initialize DataChat with the sample data
    chat = DataChat(file_path=sample_file)
    
    print("DataChat Example")
    print("----------------")
    print(chat.get_dataframe_info())
    print("\nAsking some example questions:")
    
    # Example questions
    questions = [
        "What is the average salary in the dataset?",
        "Which department has the highest average salary?",
        "Is there a correlation between years of experience and salary?",
        "Who is the oldest person in the dataset?",
        "How many people work in each department?"
    ]
    
    for i, question in enumerate(questions, 1):
        print(f"\n{i}. Question: {question}")
        print("Thinking...")
        response = chat.query(question)
        print(f"Answer: {response}")
    
    # Example of filtering data
    print("\nFiltering data to only show Engineering department:")
    chat.filter_data({"Department": "Engineering"})
    print(chat.get_dataframe_info())
    
    # Ask a question about the filtered data
    question = "What is the average salary in this filtered dataset?"
    print(f"\nQuestion: {question}")
    print("Thinking...")
    response = chat.query(question)
    print(f"Answer: {response}")
    
    # Reset filters
    print("\nResetting filters to show all data again:")
    chat.reset_filters()
    print(chat.get_dataframe_info())


if __name__ == "__main__":
    main() 