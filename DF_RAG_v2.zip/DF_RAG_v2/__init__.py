"""
DataChat - Talk to your CSV and Excel data using natural language
"""

from datachat import DataChat

__version__ = "0.1.0"
__all__ = ["DataChat"] 