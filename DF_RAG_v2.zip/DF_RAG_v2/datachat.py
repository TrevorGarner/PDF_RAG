import json
import os
from typing import Optional, Dict, Any, List, Union

from llm import LLMFactory
from data_handler import DataHandler


class DataChat:
    """
    A tool for interacting with CSV and Excel data using natural language through an LLM
    """
    
    def __init__(
        self, 
        file_path: Optional[str] = None,
        llm_backend: str = "ollama",
        llm_model: Optional[str] = None,
        max_context_rows: int = 100
    ):
        """
        Initialize the DataChat tool
        
        Args:
            file_path: Optional path to a data file to load
            llm_backend: The LLM backend to use (currently only 'ollama' is supported)
            llm_model: The model to use with the LLM backend
            max_context_rows: Maximum number of rows to include in the context
        """
        self.data_handler = DataHandler(file_path)
        self.llm = LLMFactory.create(llm_backend, model=llm_model)
        self.max_context_rows = max_context_rows
        self.conversation_history = []
    
    def load_data(self, file_path: str) -> bool:
        """
        Load data from a CSV or Excel file
        
        Args:
            file_path: Path to the data file
            
        Returns:
            True if loading was successful, False otherwise
        """
        return self.data_handler.load_data(file_path)
    
    def _build_system_prompt(self) -> str:
        """
        Build the system prompt for the LLM
        
        Returns:
            The system prompt string
        """
        if self.data_handler.df is None:
            return "You are an AI assistant that helps users analyze data. No data is currently loaded."
        
        df_info = self.data_handler.get_dataframe_info()
        
        system_prompt = f"""You are an AI assistant that helps users analyze data from {self.data_handler.file_path}.
        
The data has the following structure:
{df_info}

Your task is to:
1. Understand the user's question about the data
2. Provide accurate and helpful answers based on the data provided
3. When appropriate, suggest additional insights or visualizations that might be helpful
4. If you're unsure about something or need more information, ask clarifying questions

Important guidelines:
- Base your answers ONLY on the data provided, not on external knowledge
- If the user asks for something that cannot be determined from the data, explain why
- Be precise and accurate in your descriptions of the data
- When referring to columns, use the exact column names from the data
- If the user's question is ambiguous, ask for clarification
- Format numerical results appropriately (e.g., use appropriate decimal places, units)
- When describing trends or patterns, provide specific examples from the data
"""
        
        return system_prompt
    
    def _build_user_prompt(self, query: str) -> str:
        """
        Build the user prompt for the LLM, including data context
        
        Args:
            query: The user's query
            
        Returns:
            The complete user prompt string
        """
        context = self.data_handler.get_context_for_llm(self.max_context_rows)
        
        # Convert context to a formatted string
        context_str = json.dumps(context, indent=2)
        
        user_prompt = f"""
User Query: {query}

Data Context:
{context_str}

Please analyze the data and answer the query based on the provided context.
"""
        
        return user_prompt
    
    def query(self, query: str) -> str:
        """
        Query the data using natural language
        
        Args:
            query: The user's natural language query
            
        Returns:
            The LLM's response
        """
        if self.data_handler.df is None:
            return "No data is currently loaded. Please load a CSV or Excel file first."
        
        system_prompt = self._build_system_prompt()
        user_prompt = self._build_user_prompt(query)
        
        # Add to conversation history
        self.conversation_history.append({"role": "user", "content": query})
        
        # Generate response from LLM
        response = self.llm.generate(user_prompt, system_prompt=system_prompt)
        
        # Add to conversation history
        self.conversation_history.append({"role": "assistant", "content": response})
        
        return response
    
    def get_dataframe(self) -> Any:
        """
        Get the current dataframe
        
        Returns:
            The pandas DataFrame object or None if no data is loaded
        """
        return self.data_handler.df
    
    def get_dataframe_info(self) -> str:
        """
        Get information about the current dataframe
        
        Returns:
            A string with information about the dataframe
        """
        return self.data_handler.get_dataframe_info()
    
    def filter_data(self, filter_query: Dict[str, Any]) -> None:
        """
        Filter the dataframe based on a query dictionary
        
        Args:
            filter_query: A dictionary with column names as keys and filter values
        """
        if self.data_handler.df is None:
            return
        
        self.data_handler.df = self.data_handler.filter_dataframe(filter_query)
        self.data_handler._generate_metadata()
    
    def reset_filters(self) -> None:
        """Reset any filters applied to the dataframe"""
        if self.data_handler.file_path:
            self.data_handler.load_data(self.data_handler.file_path)
    
    def clear_conversation(self) -> None:
        """Clear the conversation history"""
        self.conversation_history = [] 