#!/usr/bin/env python3
import os
import sys
import argparse
from datachat import DataChat


def main():
    parser = argparse.ArgumentParser(description="DataChat - Talk to your CSV and Excel data using natural language")
    parser.add_argument("file", nargs="?", help="Path to CSV or Excel file")
    parser.add_argument("--model", help="Ollama model to use (default: from env or 'llama3')")
    parser.add_argument("--max-rows", type=int, default=100, help="Maximum number of rows to include in context (default: 100)")
    args = parser.parse_args()
    
    # Initialize DataChat
    chat = DataChat(
        file_path=args.file,
        llm_model=args.model,
        max_context_rows=args.max_rows
    )
    
    if not args.file:
        print("Welcome to DataChat! Please load a CSV or Excel file to begin.")
        while True:
            file_path = input("Enter path to CSV or Excel file (or 'exit' to quit): ")
            if file_path.lower() == 'exit':
                sys.exit(0)
            if chat.load_data(file_path):
                print(f"Successfully loaded {file_path}")
                print(chat.get_dataframe_info())
                break
            else:
                print(f"Failed to load {file_path}. Please try again.")
    else:
        if not os.path.exists(args.file):
            print(f"Error: File '{args.file}' not found.")
            sys.exit(1)
        print(f"Successfully loaded {args.file}")
        print(chat.get_dataframe_info())
    
    print("\nYou can now ask questions about your data. Type 'exit' to quit, 'load' to load a different file,")
    print("'info' to see dataframe info, or 'reset' to reset any filters.")
    
    # Main interaction loop
    while True:
        try:
            query = input("\nYour question: ")
            
            if query.lower() == 'exit':
                break
            elif query.lower() == 'load':
                file_path = input("Enter path to CSV or Excel file: ")
                if chat.load_data(file_path):
                    print(f"Successfully loaded {file_path}")
                    print(chat.get_dataframe_info())
                else:
                    print(f"Failed to load {file_path}.")
            elif query.lower() == 'info':
                print(chat.get_dataframe_info())
            elif query.lower() == 'reset':
                chat.reset_filters()
                print("Filters reset.")
            else:
                print("\nThinking...")
                response = chat.query(query)
                print(f"\nDataChat: {response}")
        except KeyboardInterrupt:
            print("\nExiting...")
            break
        except Exception as e:
            print(f"Error: {str(e)}")


if __name__ == "__main__":
    main() 