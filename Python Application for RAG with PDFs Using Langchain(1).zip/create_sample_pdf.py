"""
Sample PDF for testing the PDF processor module
"""

import os
from reportlab.lib.pagesizes import letter
from reportlab.pdfgen import canvas
from reportlab.lib import colors
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer

def create_sample_pdf(output_path):
    """Create a sample PDF file with multiple pages for testing."""
    doc = SimpleDocTemplate(output_path, pagesize=letter)
    styles = getSampleStyleSheet()
    style_normal = styles["Normal"]
    style_heading = styles["Heading1"]
    
    # Create content
    story = []
    
    # Page 1
    story.append(Paragraph("Sample PDF Document for RAG Testing", style_heading))
    story.append(Spacer(1, 12))
    story.append(Paragraph("This is a sample PDF document created for testing the PDF processing module of our RAG application. It contains multiple pages with different content to test the extraction and chunking capabilities.", style_normal))
    story.append(Spacer(1, 12))
    story.append(Paragraph("Page 1: Introduction", style_heading))
    story.append(Spacer(1, 12))
    
    intro_text = """
    Retrieval Augmented Generation (RAG) is a technique that enhances large language models by providing them with external knowledge. 
    Instead of relying solely on the knowledge encoded in the model's parameters, RAG systems retrieve relevant information from a knowledge base and use it to generate more accurate and informed responses.
    
    The key components of a RAG system include:
    1. A document store containing the knowledge base
    2. An embedding model to convert text into vector representations
    3. A vector database for efficient similarity search
    4. A retrieval mechanism to find relevant documents
    5. A language model to generate responses based on the retrieved context
    
    This sample PDF will help test our system's ability to process documents, extract text, and create meaningful chunks that can be embedded and retrieved later.
    """
    story.append(Paragraph(intro_text, style_normal))
    
    # Page 2
    story.append(Paragraph("Page 2: Technical Details", style_heading))
    story.append(Spacer(1, 12))
    
    tech_text = """
    The PDF processing module in our RAG application performs several important functions:
    
    Document Loading: The module uses PyPDFLoader from LangChain to load PDF files and extract their text content. This loader handles the complexities of PDF parsing and provides a clean interface for accessing the document's content.
    
    Metadata Extraction: For each page extracted from a PDF, the module adds metadata such as the source filename and page number. This metadata is crucial for traceability, allowing the system to reference the original source when providing information.
    
    Text Chunking: Long documents are split into smaller, manageable chunks using the RecursiveCharacterTextSplitter. This splitter breaks text at natural boundaries like paragraphs and sentences, ensuring that the resulting chunks maintain semantic coherence.
    
    The chunking process uses parameters like chunk_size and chunk_overlap to control the size of the chunks and the amount of overlap between consecutive chunks. Overlap is important to maintain context across chunk boundaries.
    
    Error Handling: The module includes robust error handling to deal with corrupted or incompatible PDF files, ensuring that processing can continue even if some files cannot be loaded.
    """
    story.append(Paragraph(tech_text, style_normal))
    
    # Page 3
    story.append(Paragraph("Page 3: Implementation Considerations", style_heading))
    story.append(Spacer(1, 12))
    
    impl_text = """
    When implementing a RAG system, several considerations must be taken into account:
    
    Embedding Quality: The choice of embedding model significantly impacts retrieval performance. Models like OpenAI's text-embedding-ada-002 or sentence-transformers provide high-quality embeddings but differ in cost, speed, and accuracy.
    
    Chunking Strategy: The way documents are chunked affects retrieval precision. Chunks that are too large may contain irrelevant information, while chunks that are too small may lose context. Finding the right balance is crucial.
    
    Vector Database Selection: Different vector databases (Chroma, FAISS, Pinecone, etc.) offer various trade-offs in terms of speed, scalability, and feature set. The choice depends on the specific requirements of the application.
    
    Answer Verification: In applications where accuracy is critical, implementing a verification mechanism to check if the generated answers are supported by the retrieved documents is essential. This can involve techniques like entailment models or token-level comparison.
    
    User Interface: The interface should be intuitive and provide transparency about the sources of information, allowing users to verify the reliability of the responses.
    
    By carefully addressing these considerations, we can build a robust RAG system that provides accurate and trustworthy information to users.
    """
    story.append(Paragraph(impl_text, style_normal))
    
    # Build the PDF
    doc.build(story)
    
    return output_path

if __name__ == "__main__":
    # Create sample PDF in the data directory
    os.makedirs("data", exist_ok=True)
    pdf_path = create_sample_pdf("data/sample.pdf")
    print(f"Created sample PDF at {pdf_path}")
