"""
Debug script to examine the content of PDF documents
"""

from pdf_processor import PDFProcessor

def examine_pdf_content():
    """Examine the content of PDF documents to debug verification issues."""
    processor = PDFProcessor()
    
    # List available PDFs
    pdf_files = processor.list_pdf_files()
    print(f"Found {len(pdf_files)} PDF files:")
    for pdf_file in pdf_files:
        print(f"  - {pdf_file}")
    
    # Process all documents
    chunks = processor.process_all_documents()
    print(f"\nProcessed {len(chunks)} chunks from all documents")
    
    # Print sample chunks
    print("\n=== Sample Chunks ===")
    for i, chunk in enumerate(chunks[:5]):
        print(f"\nChunk {i+1}:")
        print(f"Source: {chunk.metadata.get('source')}")
        print(f"Page: {chunk.metadata.get('page')}")
        print(f"Content: {chunk.page_content[:300]}...")

if __name__ == "__main__":
    examine_pdf_content()
