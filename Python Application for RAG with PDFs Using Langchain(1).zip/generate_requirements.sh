#!/bin/bash

# Generate requirements.txt file for the PDF RAG application

echo "Generating requirements.txt file..."

cat > requirements.txt << EOL
langchain==0.3.22
langchain-community==0.3.20
pypdf==5.4.0
python-dotenv==1.1.0
scikit-learn==1.6.1
numpy==2.2.4
streamlit==1.44.1
reportlab==4.3.1
EOL

echo "requirements.txt file created successfully."
