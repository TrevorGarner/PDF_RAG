"""
Answer Verification System for PDF RAG Application

This module implements the verification system that checks if yes/no answers
are logically supported by evidence in the PDF documents.
"""

import os
from typing import List, Dict, Any, Tuple
import re
from dotenv import load_dotenv

from lightweight_vector_store import LightweightVectorStore
from rag_query_system import RAGQuerySystem

# Load environment variables
load_dotenv()

class AnswerVerificationSystem:
    """
    Answer Verification System that checks if yes/no answers are logically supported
    by evidence in the PDF documents through deduction.
    """
    
    def __init__(self, rag_system=None):
        """
        Initialize the Answer Verification System.
        
        Args:
            rag_system: RAG system for document retrieval (created if None)
        """
        # Initialize RAG system
        self.rag_system = rag_system or RAGQuerySystem()
    
    def verify_answer(self, question: str, user_answer: str, k: int = 4) -> Dict[str, Any]:
        """
        Verify if a yes/no answer is logically supported by evidence in the documents.
        
        Args:
            question: The question being answered
            user_answer: The yes/no answer provided by the user
            k: Number of document chunks to retrieve
            
        Returns:
            Dictionary containing verification results and evidence
        """
        # Normalize and validate the user answer
        normalized_answer = self._normalize_yes_no_answer(user_answer)
        if normalized_answer not in ["yes", "no"]:
            return {
                "verified": False,
                "confidence": 0.0,
                "explanation": f"The answer must be 'yes' or 'no', but got '{user_answer}'.",
                "evidence": [],
                "source_chunks": []
            }
        
        # Retrieve relevant chunks for the question
        chunks_with_scores = self.rag_system.retrieve_with_scores(question, k=k)
        
        if not chunks_with_scores:
            return {
                "verified": False,
                "confidence": 0.0,
                "explanation": "No relevant documents found to verify the answer.",
                "evidence": [],
                "source_chunks": []
            }
        
        # Extract chunks and scores
        chunks = [chunk for chunk, _ in chunks_with_scores]
        scores = [score for _, score in chunks_with_scores]
        
        # Perform logical verification for yes/no answer
        verification_result = self._verify_yes_no_with_evidence(question, normalized_answer, chunks, scores)
        
        # Extract source information
        sources = self._extract_sources(chunks)
        
        return {
            "verified": verification_result["verified"],
            "confidence": verification_result["confidence"],
            "explanation": verification_result["explanation"],
            "evidence": verification_result["evidence"],
            "sources": sources,
            "source_chunks": chunks
        }
    
    def _normalize_yes_no_answer(self, answer: str) -> str:
        """
        Normalize a yes/no answer to standard form.
        
        Args:
            answer: The answer to normalize
            
        Returns:
            Normalized answer as 'yes', 'no', or the original if not recognized
        """
        answer = self._normalize_text(answer)
        
        # Check for yes variations
        yes_patterns = [
            r'^yes$', r'^yeah$', r'^yep$', r'^correct$', r'^right$', r'^true$', 
            r'^affirmative$', r'^indeed$', r'^absolutely$', r'^definitely$'
        ]
        
        # Check for no variations
        no_patterns = [
            r'^no$', r'^nope$', r'^incorrect$', r'^wrong$', r'^false$', 
            r'^negative$', r'^not correct$', r'^definitely not$', r'^absolutely not$'
        ]
        
        for pattern in yes_patterns:
            if re.match(pattern, answer):
                return "yes"
                
        for pattern in no_patterns:
            if re.match(pattern, answer):
                return "no"
        
        return answer
    
    def _verify_yes_no_with_evidence(self, question: str, user_answer: str, 
                                    chunks: List[Dict[str, Any]], scores: List[float]) -> Dict[str, Any]:
        """
        Verify a yes/no answer through logical deduction based on evidence.
        
        Args:
            question: The question being answered
            user_answer: The normalized yes/no answer
            chunks: Retrieved document chunks
            scores: Similarity scores for chunks
            
        Returns:
            Dictionary with verification results and evidence
        """
        # Extract key terms from the question for matching
        question_normalized = self._normalize_text(question)
        question_terms = self._extract_key_terms(question_normalized)
        
        # Extract key concepts from the question
        question_concepts = self._extract_question_concepts(question_normalized)
        
        # Analyze the question type to determine expected evidence
        question_type = self._analyze_question_type(question_normalized)
        
        # Process each chunk to determine if it supports or contradicts the answer
        evidence_chunks = []
        yes_evidence_score = 0.0
        no_evidence_score = 0.0
        
        # Debug information
        print(f"Question: {question}")
        print(f"Question type: {question_type}")
        print(f"Key concepts: {question_concepts}")
        
        for chunk, score in zip(chunks, scores):
            chunk_text = chunk.page_content
            chunk_normalized = self._normalize_text(chunk_text)
            
            # Check if chunk contains key terms from the question
            relevance_score = self._calculate_relevance(chunk_normalized, question_terms, question_concepts)
            
            # Skip chunks with very low relevance
            if relevance_score < 0.1:
                continue
                
            # Determine if the chunk supports a yes or no answer
            evidence_result = self._analyze_evidence(question_concepts, question_type, chunk_text, relevance_score)
            
            # Debug information
            print(f"\nChunk from {chunk.metadata.get('source', 'Unknown')} (Relevance: {relevance_score:.2f}):")
            print(f"Text: {chunk_text[:100]}...")
            print(f"Supports yes: {evidence_result['supports_yes']}, Strength: {evidence_result['yes_strength']:.2f}")
            print(f"Supports no: {evidence_result['supports_no']}, Strength: {evidence_result['no_strength']:.2f}")
            
            # Add to evidence chunks with analysis
            evidence_chunks.append({
                "text": chunk_text,
                "relevance": relevance_score,
                "supports_yes": evidence_result["supports_yes"],
                "supports_no": evidence_result["supports_no"],
                "yes_strength": evidence_result["yes_strength"],
                "no_strength": evidence_result["no_strength"],
                "score": score,
                "source": chunk.metadata.get("source", "Unknown"),
                "page": chunk.metadata.get("page", 1)
            })
            
            # Update evidence scores
            yes_evidence_score += evidence_result["yes_strength"] * score * relevance_score
            no_evidence_score += evidence_result["no_strength"] * score * relevance_score
        
        # Apply question-specific adjustments based on question type
        if question_type == "definition":
            # For definition questions, we need stronger evidence
            yes_evidence_score *= 0.8
            no_evidence_score *= 0.8
        elif question_type == "negative":
            # For negative questions (e.g., "Is X a virus?"), default to "no" unless strong evidence
            no_evidence_score += 0.5
        elif question_type == "irrelevant":
            # For questions about irrelevance, default to "no" (things are usually relevant)
            # Apply a stronger bias for irrelevance questions
            no_evidence_score += 0.7
            yes_evidence_score *= 0.5  # Reduce the weight of yes evidence for irrelevance questions
        
        # Debug information
        print(f"\nEvidence scores - Yes: {yes_evidence_score:.2f}, No: {no_evidence_score:.2f}")
        
        # Determine which answer has more evidence support
        total_evidence = yes_evidence_score + no_evidence_score
        
        if total_evidence < 0.05:
            # Not enough evidence either way
            verified = False
            confidence = 0.0
            explanation = f"No clear evidence was found to verify the '{user_answer}' answer to this question."
        else:
            # Calculate confidence based on the balance of evidence
            yes_confidence = yes_evidence_score / total_evidence if total_evidence > 0 else 0.0
            no_confidence = no_evidence_score / total_evidence if total_evidence > 0 else 0.0
            
            # Determine which answer is supported by the evidence
            if yes_confidence > 0.6 and yes_evidence_score > 0.1:
                supported_answer = "yes"
                confidence = yes_confidence
            elif no_confidence > 0.6 and no_evidence_score > 0.1:
                supported_answer = "no"
                confidence = no_confidence
            else:
                supported_answer = None
                confidence = max(yes_confidence, no_confidence)
            
            # Check if the user's answer matches the supported answer
            if supported_answer == user_answer:
                verified = True
                explanation = f"The '{user_answer}' answer is logically supported by the evidence with {confidence:.1%} confidence."
            else:
                verified = False
                if supported_answer:
                    explanation = f"The evidence suggests the answer is '{supported_answer}' with {confidence:.1%} confidence, not '{user_answer}'."
                else:
                    explanation = f"The evidence is inconclusive (only {confidence:.1%} confidence for any answer)."
        
        # Format evidence for output
        formatted_evidence = []
        for chunk in evidence_chunks:
            if user_answer == "yes":
                supports = chunk["supports_yes"]
                contradicts = chunk["supports_no"]
                strength = chunk["yes_strength"] if supports else chunk["no_strength"]
            else:  # user_answer == "no"
                supports = chunk["supports_no"]
                contradicts = chunk["supports_yes"]
                strength = chunk["no_strength"] if supports else chunk["yes_strength"]
            
            formatted_evidence.append({
                "text": chunk["text"],
                "relevance": chunk["relevance"],
                "supports": supports,
                "contradicts": contradicts,
                "strength": strength,
                "score": chunk["score"],
                "source": chunk["source"],
                "page": chunk["page"]
            })
        
        # Sort evidence chunks by relevance and support (most relevant and supporting first)
        formatted_evidence.sort(key=lambda x: (x["relevance"] * (2 if x["supports"] else -1 if x["contradicts"] else 0)), reverse=True)
        
        return {
            "verified": verified,
            "confidence": confidence,
            "explanation": explanation,
            "evidence": formatted_evidence
        }
    
    def _analyze_question_type(self, question: str) -> str:
        """
        Analyze the type of question to determine verification approach.
        
        Args:
            question: The normalized question text
            
        Returns:
            Question type as a string
        """
        # Check for definition questions
        definition_patterns = [
            "what is", "what are", "define", "meaning of", "stand for", "definition of"
        ]
        for pattern in definition_patterns:
            if pattern in question:
                return "definition"
        
        # Check for negative questions (asking if something is bad/wrong/etc.)
        negative_patterns = [
            "virus", "malware", "incorrect", "wrong", "bad", "harmful", "dangerous",
            "useless"
        ]
        for pattern in negative_patterns:
            if pattern in question:
                return "negative"
        
        # Check for irrelevance questions - this needs to be checked before capability
        irrelevance_patterns = [
            "irrelevant", "unimportant", "insignificant", "unnecessary", "not important",
            "not necessary", "not significant", "not relevant"
        ]
        for pattern in irrelevance_patterns:
            if pattern in question:
                return "irrelevant"
        
        # Check for capability questions
        capability_patterns = [
            "can", "could", "able to", "capability", "enhance", "improve", "support"
        ]
        for pattern in capability_patterns:
            if pattern in question:
                return "capability"
        
        # Default to general question
        return "general"
    
    def _extract_question_concepts(self, question: str) -> Dict[str, Any]:
        """
        Extract key concepts from a question for verification.
        
        Args:
            question: The normalized question text
            
        Returns:
            Dictionary with question concepts
        """
        # Initialize concepts
        concepts = {
            "subject": "",
            "predicate": "",
            "is_negated": False,
            "key_entities": []
        }
        
        # Remove question words and extract subject/predicate
        question_words = ["does", "do", "did", "is", "are", "was", "were", "will", "would", "can", "could", "should"]
        cleaned_question = question
        
        for word in question_words:
            if question.startswith(word + " "):
                cleaned_question = question[len(word)+1:]
                break
        
        # Check for negation
        if "not" in cleaned_question or "n't" in cleaned_question:
            concepts["is_negated"] = True
            cleaned_question = cleaned_question.replace(" not ", " ").replace("n't", "")
        
        # Extract subject and predicate
        parts = cleaned_question.split()
        if len(parts) <= 2:
            concepts["subject"] = cleaned_question
        else:
            # Try to find the verb to separate subject from predicate
            verb_positions = []
            for i, word in enumerate(parts):
                if word in ["is", "are", "was", "were", "will", "would", "can", "could", "should", "have", "has", "had", "enhance", "stand", "contain", "include", "affect"]:
                    verb_positions.append(i)
            
            if verb_positions:
                first_verb = min(verb_positions)
                concepts["subject"] = " ".join(parts[:first_verb])
                concepts["predicate"] = " ".join(parts[first_verb:])
            else:
                # If no verb found, take the first third as the subject
                subject_end = max(1, len(parts) // 3)
                concepts["subject"] = " ".join(parts[:subject_end])
                concepts["predicate"] = " ".join(parts[subject_end:])
        
        # Extract key entities (nouns and noun phrases)
        stop_words = {'a', 'an', 'the', 'and', 'or', 'but', 'is', 'are', 'was', 'were', 
                     'in', 'on', 'at', 'to', 'for', 'with', 'by', 'about', 'as', 'of',
                     'does', 'do', 'did', 'will', 'would', 'can', 'could', 'should'}
        
        # Simple no
(Content truncated due to size limit. Use line ranges to read in chunks)