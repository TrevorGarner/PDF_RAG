"""
Test Suite for PDF RAG Application

This module contains test cases for the PDF RAG application components.
"""

import unittest
import os
import sys
from dotenv import load_dotenv

# Add the current directory to the path for imports
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

# Import application components
from pdf_processor import PDFProcessor
from lightweight_vector_store import LightweightVectorStore
from rag_query_system import RAGQuerySystem
from answer_verification import AnswerVerificationSystem
from additional_features import AdditionalFeatures

# Load environment variables
load_dotenv()

class TestPDFProcessor(unittest.TestCase):
    """Test cases for the PDF Processor module."""
    
    def setUp(self):
        """Set up test environment."""
        self.processor = PDFProcessor()
    
    def test_list_pdf_files(self):
        """Test listing PDF files."""
        pdf_files = self.processor.list_pdf_files()
        self.assertIsInstance(pdf_files, list)
        # At least one PDF file should be present (sample.pdf)
        self.assertGreaterEqual(len(pdf_files), 1)
    
    def test_load_pdf(self):
        """Test loading a PDF file."""
        pdf_files = self.processor.list_pdf_files()
        if pdf_files:
            pages = self.processor.load_pdf(pdf_files[0])
            self.assertIsInstance(pages, list)
            self.assertGreaterEqual(len(pages), 1)
            # Check metadata
            self.assertIn('source', pages[0].metadata)
            self.assertIn('page', pages[0].metadata)
    
    def test_chunk_documents(self):
        """Test chunking documents."""
        pdf_files = self.processor.list_pdf_files()
        if pdf_files:
            pages = self.processor.load_pdf(pdf_files[0])
            chunks = self.processor.chunk_documents(pages)
            self.assertIsInstance(chunks, list)
            self.assertGreaterEqual(len(chunks), 1)


class TestVectorStore(unittest.TestCase):
    """Test cases for the Vector Store module."""
    
    def setUp(self):
        """Set up test environment."""
        self.processor = PDFProcessor()
        self.vector_store = LightweightVectorStore()
    
    def test_add_documents(self):
        """Test adding documents to the vector store."""
        chunks = self.processor.process_all_documents()
        if chunks:
            self.vector_store.add_documents(chunks)
            stats = self.vector_store.get_collection_stats()
            self.assertEqual(stats["status"], "populated")
            # Just verify documents were added, count may vary due to persistence
            self.assertGreater(stats["count"], 0)
    
    def test_similarity_search(self):
        """Test similarity search."""
        chunks = self.processor.process_all_documents()
        if chunks:
            self.vector_store.add_documents(chunks)
            results = self.vector_store.similarity_search("RAG", k=2)
            self.assertIsInstance(results, list)
            self.assertLessEqual(len(results), 2)
            if results:
                self.assertTrue(hasattr(results[0], 'page_content'))
                self.assertTrue(hasattr(results[0], 'metadata'))


class TestRAGQuerySystem(unittest.TestCase):
    """Test cases for the RAG Query System."""
    
    def setUp(self):
        """Set up test environment."""
        self.rag_system = RAGQuerySystem()
    
    def test_retrieve_relevant_chunks(self):
        """Test retrieving relevant chunks."""
        chunks = self.rag_system.retrieve_relevant_chunks("What is RAG?", k=2)
        self.assertIsInstance(chunks, list)
        if chunks:
            self.assertTrue(hasattr(chunks[0], 'page_content'))
            self.assertTrue(hasattr(chunks[0], 'metadata'))
    
    def test_generate_response(self):
        """Test generating a response."""
        result = self.rag_system.generate_response("What is RAG?", k=2)
        self.assertIsInstance(result, dict)
        self.assertIn("answer", result)
        self.assertIn("sources", result)
        self.assertIn("source_chunks", result)


class TestAnswerVerification(unittest.TestCase):
    """Test cases for the Answer Verification System."""
    
    def setUp(self):
        """Set up test environment."""
        self.verifier = AnswerVerificationSystem()
    
    def test_verify_correct_answer(self):
        """Test verifying a correct answer."""
        question = "What is RAG?"
        correct_answer = "RAG is Retrieval Augmented Generation, a technique that enhances language models by providing them with external knowledge."
        result = self.verifier.verify_answer(question, correct_answer)
        self.assertIsInstance(result, dict)
        self.assertIn("verified", result)
        self.assertIn("confidence", result)
        self.assertIn("explanation", result)
        self.assertIn("evidence", result)
        self.assertIn("sources", result)
    
    def test_verify_incorrect_answer(self):
        """Test verifying an incorrect answer."""
        question = "What is RAG?"
        incorrect_answer = "RAG is a type of computer virus that affects PDF documents."
        result = self.verifier.verify_answer(question, incorrect_answer)
        self.assertIsInstance(result, dict)
        self.assertIn("verified", result)
        self.assertIn("confidence", result)
        self.assertIn("explanation", result)
        self.assertIn("evidence", result)
        self.assertIn("sources", result)


class TestAdditionalFeatures(unittest.TestCase):
    """Test cases for the Additional Features module."""
    
    def setUp(self):
        """Set up test environment."""
        self.features = AdditionalFeatures()
    
    def test_summarize_document(self):
        """Test document summarization."""
        result = self.features.summarize_document()
        self.assertIsInstance(result, dict)
        self.assertIn("summary", result)
        self.assertIn("sources", result)
    
    def test_answer_question(self):
        """Test enhanced question answering."""
        result = self.features.answer_question("What are the components of a RAG system?")
        self.assertIsInstance(result, dict)
        self.assertIn("answer", result)
        self.assertIn("sources", result)
        self.assertIn("source_chunks", result)
    
    def test_explore_document_metadata(self):
        """Test document metadata exploration."""
        result = self.features.explore_document_metadata()
        self.assertIsInstance(result, dict)
        self.assertIn("analysis", result)
        self.assertIn("documents", result)


def run_tests():
    """Run all tests."""
    unittest.main()


if __name__ == "__main__":
    run_tests()
