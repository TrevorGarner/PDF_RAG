# PDF RAG Application with Yes/No Answer Verification

This application implements a Retrieval Augmented Generation (RAG) system for PDF documents with specialized yes/no answer verification capabilities. The system can verify if yes/no answers to questions are logically supported by evidence in the PDF documents.

## Features

- **PDF Processing**: Load and process PDF documents, extract text, and chunk documents with metadata
- **Vector Store**: Store and retrieve document chunks using TF-IDF based vector similarity
- **RAG Query System**: Ask questions about the content of PDF documents
- **Answer Verification**: Verify if answers are supported by evidence in the documents
- **Yes/No Verification**: Specialized verification for yes/no questions with logical deduction
- **Document Summarization**: Generate summaries of documents
- **Metadata Explorer**: Explore metadata information from documents
- **Command-line Interface**: Interact with the system through a text-based interface
- **Web Interface**: Interact with the system through a graphical user interface

## Installation

1. Create a virtual environment:
```bash
python3 -m venv venv
source venv/bin/activate
```

2. Install dependencies:
```bash
pip install -r requirements.txt
```

## Usage

### Command-line Interface

Run the command-line interface:

```bash
python cli.py
```

Available commands:

- `list`: List available PDF documents
- `query <question>`: Query the RAG system
- `verify <question> <answer>`: Verify an answer
- `verify-yn <question> <yes/no>`: Verify a yes/no answer with detailed analysis
- `summarize`: Summarize all documents
- `summarize <document>`: Summarize a specific document
- `metadata`: Explore document metadata
- `interactive`: Start interactive mode

### Web Interface

Run the web interface:

```bash
streamlit run web_interface.py
```

The web interface provides the following pages:

- **Home**: Overview of the system and available documents
- **Query System**: Ask questions about the content of PDF documents
- **Answer Verification**: Verify if an answer is supported by evidence in the documents
- **Yes/No Verification**: Specialized verification for yes/no questions with logical deduction
- **Document Summarization**: Generate summaries of documents
- **Metadata Explorer**: Explore metadata information from documents

## Yes/No Answer Verification

The system uses a specialized verification approach for yes/no questions:

1. **Question Analysis**: The system analyzes the question to determine its type (definition, capability, negative, irrelevant) and extracts key concepts.
2. **Evidence Retrieval**: The system retrieves relevant document chunks based on the question.
3. **Evidence Analysis**: The system analyzes each chunk to determine if it supports a "yes" or "no" answer.
4. **Logical Deduction**: The system uses logical deduction to determine if the evidence supports the answer, considering the question type and context.
5. **Confidence Calculation**: The system calculates a confidence score for the verification result.

The system can handle various types of yes/no questions, including:
- Definition questions (e.g., "Does RAG stand for Retrieval Augmented Generation?")
- Capability questions (e.g., "Does RAG enhance language models with external knowledge?")
- Negative questions (e.g., "Is RAG a type of computer virus?")
- Irrelevance questions (e.g., "Is chunking strategy irrelevant in RAG systems?")

## Project Structure

- `pdf_processor.py`: PDF loading and processing module
- `lightweight_vector_store.py`: Vector store implementation
- `rag_query_system.py`: RAG query system implementation
- `answer_verification.py`: Answer verification system implementation
- `additional_features.py`: Additional features implementation
- `cli.py`: Command-line interface implementation
- `web_interface.py`: Web interface implementation
- `main.py`: Main entry point for the application
- `data/`: Directory for PDF documents
- `chroma_db/`: Directory for vector store data

## Requirements

See `requirements.txt` for the list of dependencies.

## License

This project is licensed under the MIT License - see the LICENSE file for details.
