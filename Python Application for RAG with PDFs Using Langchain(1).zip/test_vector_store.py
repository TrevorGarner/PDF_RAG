"""
Test script for the lightweight vector store implementation
"""

from src.lightweight_vector_store import LightweightVectorStore
from src.pdf_processor import PDFProcessor

def main():
    # Process PDFs
    processor = PDFProcessor()
    chunks = processor.process_all_documents()
    print(f"Created {len(chunks)} document chunks")
    
    # Store in vector database
    vector_store = LightweightVectorStore()
    vector_store.add_documents(chunks)
    
    # Get collection stats
    stats = vector_store.get_collection_stats()
    print(f"Vector store stats: {stats}")
    
    # Test similarity search
    if chunks:
        results = vector_store.similarity_search("What is RAG?", k=2)
        print("\nSimilarity search results for 'What is RAG?':")
        for i, doc in enumerate(results):
            print(f"\nResult {i+1}:")
            print(f"Content: {doc.page_content[:200]}...")
            print(f"Metadata: {doc.metadata}")
        
        # Test with another query
        results = vector_store.similarity_search("What are the components of a RAG system?", k=2)
        print("\nSimilarity search results for 'What are the components of a RAG system?':")
        for i, doc in enumerate(results):
            print(f"\nResult {i+1}:")
            print(f"Content: {doc.page_content[:200]}...")
            print(f"Metadata: {doc.metadata}")

if __name__ == "__main__":
    main()
