"""
Vector Store Module for RAG Application

This module handles embedding document chunks and storing them in a vector database
for efficient similarity search and retrieval.
"""

import os
from typing import List, Dict, Any
from pathlib import Path
from dotenv import load_dotenv
import numpy as np

from langchain_community.embeddings import HuggingFaceEmbeddings
from langchain_community.vectorstores import Chroma

# Load environment variables
load_dotenv()

class VectorStore:
    """Class for embedding and storing document chunks in a vector database."""
    
    def __init__(self, persist_directory: str = None):
        """
        Initialize the vector store.
        
        Args:
            persist_directory: Directory to persist the vector store (defaults to env variable)
        """
        self.persist_directory = persist_directory or os.getenv("CHROMA_DB_DIR", "./chroma_db")
        
        # Initialize the embedding model
        # Using a smaller model due to resource constraints
        self.embedding_model = HuggingFaceEmbeddings(
            model_name="all-MiniLM-L6-v2",
            model_kwargs={'device': 'cpu'},
            encode_kwargs={'normalize_embeddings': True}
        )
        
        # Initialize the vector store if it exists
        if os.path.exists(self.persist_directory) and os.listdir(self.persist_directory):
            self.db = Chroma(
                persist_directory=self.persist_directory,
                embedding_function=self.embedding_model
            )
        else:
            self.db = None
    
    def add_documents(self, documents: List[Dict[str, Any]]) -> None:
        """
        Add documents to the vector store.
        
        Args:
            documents: List of document chunks to add
        """
        # Create a new vector store if it doesn't exist
        if self.db is None:
            self.db = Chroma.from_documents(
                documents=documents,
                embedding=self.embedding_model,
                persist_directory=self.persist_directory
            )
        else:
            # Add documents to existing vector store
            self.db.add_documents(documents)
        
        # Persist the vector store
        self.db.persist()
    
    def similarity_search(self, query: str, k: int = 4) -> List[Dict[str, Any]]:
        """
        Perform similarity search on the vector store.
        
        Args:
            query: Query string
            k: Number of results to return
            
        Returns:
            List of document chunks most similar to the query
        """
        if self.db is None:
            raise ValueError("Vector store is empty. Add documents first.")
        
        return self.db.similarity_search(query, k=k)
    
    def similarity_search_with_score(self, query: str, k: int = 4) -> List[tuple]:
        """
        Perform similarity search on the vector store and return scores.
        
        Args:
            query: Query string
            k: Number of results to return
            
        Returns:
            List of tuples (document, score) most similar to the query
        """
        if self.db is None:
            raise ValueError("Vector store is empty. Add documents first.")
        
        return self.db.similarity_search_with_score(query, k=k)
    
    def get_collection_stats(self) -> Dict[str, Any]:
        """
        Get statistics about the vector store collection.
        
        Returns:
            Dictionary with collection statistics
        """
        if self.db is None:
            return {"count": 0, "status": "empty"}
        
        return {
            "count": self.db._collection.count(),
            "status": "populated"
        }


if __name__ == "__main__":
    # Example usage
    from pdf_processor import PDFProcessor
    
    # Process PDFs
    processor = PDFProcessor()
    chunks = processor.process_all_documents()
    print(f"Created {len(chunks)} document chunks")
    
    # Store in vector database
    vector_store = VectorStore()
    vector_store.add_documents(chunks)
    
    # Get collection stats
    stats = vector_store.get_collection_stats()
    print(f"Vector store stats: {stats}")
    
    # Test similarity search
    if chunks:
        results = vector_store.similarity_search("What is RAG?", k=2)
        print("\nSimilarity search results for 'What is RAG?':")
        for i, doc in enumerate(results):
            print(f"\nResult {i+1}:")
            print(f"Content: {doc.page_content[:200]}...")
            print(f"Metadata: {doc.metadata}")
